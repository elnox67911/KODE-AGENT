import fs from 'node:fs';
import path from 'node:path';
import { parseArgs, printHelp } from './cli.js';
import {
  CONFIG_PATH,
  PERMISSION_MODES,
  PROVIDER_PRESETS,
  VERSION,
  configSummary,
  getModelInfo,
  loadConfig,
  maskConfig,
  parseModelRef,
  projectPaths,
  resolveProvider,
  saveConfig,
} from './config.js';
import { UI } from './ui/render.js';
import { Prompter } from './ui/prompt.js';
import { Agent } from './agent/agent.js';
import { Session, loadSession, listSessions } from './session.js';
import { McpManager } from './mcp.js';
import { buildMemoryContext, readCapped } from './memory.js';
import { discoverSkills } from './skills.js';
import { discoverCommands } from './custom-commands.js';
import { handleCommand } from './commands.js';
import { runSetup } from './setup.js';
import { formatDoctor, runDoctor } from './doctor.js';
import { listRemoteModels } from './providers/index.js';
import { runHooks, collectHookContext } from './hooks.js';
import { bashTool } from './tools/bash.js';
import { expandHome, isProbablyBinary, truncateText } from './utils.js';

const IMAGE_TYPES = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.bmp': 'image/bmp',
};

function applyCliOverrides(config, options) {
  if (!config.permissions) config.permissions = {};
  if (options.provider) {
    const changed = options.provider !== config.provider;
    config.provider = options.provider;
    if (changed && !options.model) {
      const preset = PROVIDER_PRESETS[config.provider];
      const user = config.providers?.[config.provider];
      const nextModel = user?.defaultModel || preset?.defaultModel;
      if (nextModel) config.model = nextModel;
    }
  }
  if (options.model) {
    const ref = parseModelRef(config, options.model);
    config.provider = ref.provider;
    config.model = ref.model;
  }
  if (options.permissionMode) {
    if (!PERMISSION_MODES.includes(options.permissionMode)) {
      throw new Error(`Unknown permission mode "${options.permissionMode}". Use: ${PERMISSION_MODES.join(', ')}`);
    }
    config.permissions.mode = options.permissionMode;
  }
  if (options.maxTurns) config.maxTurns = options.maxTurns;
  config.__runtime = {
    provider: config.provider,
    apiKey: options.apiKey || undefined,
    baseURL: options.baseUrl || undefined,
    systemPromptAppend: options.appendSystemPrompt || undefined,
  };
}

function missingKeyMessage(provider) {
  const env = (PROVIDER_PRESETS[provider.name]?.env || []).join(' or ');
  return [
    `No API key found for ${provider.label || provider.name}.`,
    'Set one up with:  kode setup',
    env ? `Or export ${env}.` : 'Or pass --api-key for a single run.',
  ].join('\n');
}

function jsonLine(payload) {
  process.stdout.write(`${JSON.stringify(payload)}\n`);
}

export async function main(argv = process.argv.slice(2)) {
  let parsed;
  try {
    parsed = parseArgs(argv);
  } catch (err) {
    process.stderr.write(`kode: ${err.message}\n\n`);
    printHelp(process.stderr);
    return 2;
  }

  if (parsed.options.help) {
    printHelp(process.stdout);
    return 0;
  }
  if (parsed.options.version) {
    process.stdout.write(`${VERSION}\n`);
    return 0;
  }
  if (parsed.command) return runSubcommand(parsed);

  return runMain(parsed);
}

function baseUi(mode = 'print', options = {}) {
  return new UI({ mode, color: options.color !== false, verbose: Boolean(options.verbose), spinner: false });
}

async function runSubcommand(parsed) {
  const cwd = process.cwd();
  const ui = baseUi('print', parsed.options);
  let config;
  try {
    config = loadConfig();
  } catch (err) {
    ui.error(err.message);
    return 1;
  }
  try {
    applyCliOverrides(config, parsed.options);
  } catch (err) {
    ui.error(err.message);
    return 1;
  }

  if (parsed.command === 'setup') {
    if (!process.stdin.isTTY) {
      ui.error('Setup needs an interactive terminal.');
      return 1;
    }
    const interactiveUi = new UI({ mode: 'interactive', color: parsed.options.color, spinner: false });
    const prompter = new Prompter({ ui: interactiveUi, historyFile: projectPaths(cwd).history });
    try {
      await runSetup({ ui: interactiveUi, prompter, config });
      return 0;
    } catch (err) {
      interactiveUi.error(err.message);
      return 1;
    } finally {
      prompter.close();
    }
  }

  if (parsed.command === 'config') {
    process.stdout.write(`${configSummary(config).join('\n')}\n\n`);
    if (parsed.args.includes('json')) {
      process.stdout.write(`${JSON.stringify(maskConfig(config), null, 2)}\n`);
    }
    return 0;
  }

  if (parsed.command === 'sessions') {
    const sessions = listSessions(cwd, 40);
    if (!sessions.length) {
      process.stdout.write('No saved sessions for this project.\n');
      return 0;
    }
    for (const session of sessions) {
      const when = new Date(session.updatedAt || session.mtime).toLocaleString();
      process.stdout.write(`${session.id}  ${when}  ${session.title}\n`);
      process.stdout.write(`  ${session.messageCount} messages · ${session.provider || '?'}/${session.model || '?'}\n`);
    }
    return 0;
  }

  let provider;
  try {
    provider = resolveProvider(config, config.provider, config.__runtime);
  } catch (err) {
    ui.error(err.message);
    return 1;
  }

  if (parsed.command === 'models') {
    const models = provider.models.map((entry) => entry.id);
    let remote = [];
    if (parsed.options.refresh) {
      try {
        remote = await listRemoteModels(provider);
      } catch (err) {
        ui.warn(`Could not list remote models: ${err.message}`);
      }
    }
    const all = [...new Set([...models, ...remote])];
    if (!all.length) process.stdout.write('No models listed. Pass a model id with --model.\n');
    else for (const id of all) process.stdout.write(`${id === config.model ? '* ' : '  '}${id}\n`);
    return 0;
  }

  if (parsed.command === 'doctor') {
    const report = await runDoctor({
      config,
      provider,
      cwd,
      network: true,
    });
    process.stdout.write(`${formatDoctor(report)}\n`);
    return report.ok ? 0 : 1;
  }

  return 1;
}

async function runMain(parsed) {
  const { options, prompt } = parsed;
  const cwd = process.cwd();
  const stdinTty = Boolean(process.stdin.isTTY);
  const stdoutTty = Boolean(process.stdout.isTTY);
  const wantsRepl = options.repl || (!prompt && !options.print);
  const mode =
    options.outputFormat === 'json'
      ? 'json'
      : stdinTty && stdoutTty && wantsRepl
        ? 'interactive'
        : 'print';
  const ui = new UI({
    mode,
    color: options.color,
    verbose: options.verbose,
    spinner: options.spinner,
  });

  let config;
  try {
    config = loadConfig();
  } catch (err) {
    ui.error(err.message);
    return 1;
  }

  try {
    applyCliOverrides(config, options);
  } catch (err) {
    ui.error(err.message);
    return 1;
  }

  const prompter = new Prompter({ ui, historyFile: projectPaths(cwd).history });

  const explicitModelChoice = Boolean(options.provider || options.model);
  let session = null;
  if (options.resume != null) {
    session = loadSession(cwd, options.resume);
    if (!session) {
      ui.error(`Could not find a session matching "${options.resume}". Run "kode sessions" to list sessions.`);
      return 1;
    }
  } else if (options.continue) {
    session = loadSession(cwd, 'latest');
    if (!session && mode === 'interactive') ui.info('No previous session found; starting a new one.');
  }
  if (session) {
    session.cwd = cwd;
    if (!explicitModelChoice) {
      if (session.provider && session.provider !== config.provider) {
        config.provider = session.provider;
        config.__runtime.provider = session.provider;
      }
      if (session.model) config.model = session.model;
    }
  }

  let provider;
  try {
    provider = resolveProvider(config, config.provider, config.__runtime);
  } catch (err) {
    ui.error(err.message);
    prompter.close();
    return 1;
  }

  const configured = Boolean(provider.apiKey || provider.needsKey === false) && Boolean(config.model) && Boolean(provider.baseURL);
  if (!configured) {
    if (mode === 'interactive') {
      ui.line('');
      ui.line(`  ${ui.bold('Welcome to kode')} ${ui.dim(`v${VERSION}`)}`);
      ui.line(`  ${ui.dim('Let’s connect a model provider first.')}`);
      try {
        await runSetup({ ui, prompter, config });
      } catch (err) {
        ui.error(err.message);
        prompter.close();
        return 1;
      }
      config.__runtime = {
        provider: config.provider,
        systemPromptAppend: config.__runtime?.systemPromptAppend,
      };
      try {
        provider = resolveProvider(config, config.provider, config.__runtime);
      } catch (err) {
        ui.error(err.message);
        prompter.close();
        return 1;
      }
      if (!session) session = Session.create({ cwd, provider: config.provider, model: config.model });
    } else {
      if (!provider.apiKey && provider.needsKey) ui.error(missingKeyMessage(provider));
      else if (!provider.baseURL) ui.error(`Provider "${provider.name}" has no base URL. Configure it in ${CONFIG_PATH}.`);
      else ui.error('No model configured. Run "kode setup" or pass --model.');
      prompter.close();
      return 1;
    }
  }
  if (!session) {
    session = Session.create({
      cwd,
      provider: provider.name,
      model: config.model,
      mode: config.permissions.mode,
    });
  }

  if (session.mode === 'plan' && options.permissionMode && options.permissionMode !== 'plan') {
    session.prePlanMode = options.permissionMode;
  }
  if (options.permissionMode) session.mode = options.permissionMode;
  if (!PERMISSION_MODES.includes(session.mode)) session.mode = 'default';
  if (options.allowedTools.length) {
    for (const rule of options.allowedTools) session.addAllowRule(rule);
  }
  if (options.systemPrompt || options.appendSystemPrompt) {
    config.__runtime.systemPromptAppend = [options.systemPrompt, options.appendSystemPrompt]
      .filter(Boolean)
      .join('\n\n');
  }

  const memory = buildMemoryContext(cwd);
  const skills = discoverSkills(cwd);
  const customCommands = discoverCommands(cwd);

  let mcp = null;
  if (options.mcp && Object.keys(config.mcpServers || {}).length) {
    if (mode === 'interactive') ui.startSpinner('starting MCP servers');
    mcp = new McpManager({ config, ui });
    try {
      await mcp.start();
    } catch (err) {
      ui.warn(`MCP startup failed: ${err.message}`);
    }
    ui.stopSpinner();
  }

  const runtime = {
    config,
    ui,
    prompter,
    cwd,
    session,
    provider: null,
    modelInfo: null,
    mcp,
    skills,
    customCommands,
    commands: customCommands,
    memory,
    agent: null,
    autoApprove: options.yes,
    controller: null,
    exitRequested: false,
  };

  const reconfigure = () => {
    const resolved = resolveProvider(config, config.provider, config.__runtime);
    if (resolved.needsKey && !resolved.apiKey) throw new Error(missingKeyMessage(resolved));
    if (!resolved.baseURL) throw new Error(`Provider "${resolved.name}" has no base URL.`);
    if (!config.model) throw new Error('No model configured. Run /setup or pass --model.');
    const info = getModelInfo(config, resolved, config.model);
    runtime.provider = resolved;
    runtime.modelInfo = info;
    runtime.skills = discoverSkills(cwd);
    runtime.agent = new Agent({
      config,
      provider: resolved,
      modelInfo: info,
      session: runtime.session,
      ui,
      prompter,
      mcp: runtime.mcp,
      memory: runtime.memory,
      skills: runtime.skills,
      cwd,
      autoApprove: options.yes,
      maxTurns: config.maxTurns,
    });
    session.provider = resolved.name;
    session.model = info.id;
    return { provider: resolved, modelInfo: info };
  };

  try {
    reconfigure();
  } catch (err) {
    ui.error(err.message);
    mcp?.close();
    prompter.close();
    return 1;
  }

  runtime.reconfigure = reconfigure;

  runtime.resumeSession = (selector) => {
    const loaded = loadSession(cwd, selector);
    if (!loaded) return null;
    const previous = {
      session,
      providerName: config.provider,
      model: config.model,
      runtimeRef: config.__runtime,
    };
    try {
      if (!explicitModelChoice) {
        if (loaded.provider && loaded.provider !== config.provider) config.provider = loaded.provider;
        if (loaded.model) config.model = loaded.model;
        config.__runtime = { ...config.__runtime, provider: config.provider };
      }
      loaded.cwd = cwd;
      if (options.permissionMode) {
        loaded.prePlanMode = options.permissionMode === 'plan' ? loaded.mode : null;
        loaded.mode = options.permissionMode;
      }
      for (const rule of options.allowedTools) loaded.addAllowRule(rule);
      session = loaded;
      runtime.session = loaded;
      reconfigure();
      return loaded;
    } catch (err) {
      session = previous.session;
      runtime.session = previous.session;
      config.provider = previous.providerName;
      config.model = previous.model;
      config.__runtime = previous.runtimeRef;
      reconfigure();
      throw err;
    }
  };

  runtime.restartMcp = async () => {
    try {
      runtime.mcp?.close();
    } catch {}
    runtime.mcp = null;
    if (options.mcp && Object.keys(config.mcpServers || {}).length) {
      runtime.mcp = new McpManager({ config, ui });
      ui.startSpinner('starting MCP servers');
      await runtime.mcp.start();
      ui.stopSpinner();
    }
    reconfigure();
  };

  runtime.runDoctor = () =>
    runDoctor({
      config,
      provider: runtime.provider,
      cwd,
      network: true,
    });

  if (mode === 'interactive') {
    ui.banner({
      provider: runtime.provider.name,
      model: runtime.modelInfo.id,
      cwd,
      version: VERSION,
      sessionId: session.id,
    });
    if (session.messages.length) {
      ui.info(`resumed ${session.id} · ${session.title} (${session.messages.length} messages)`);
    }
    for (const server of runtime.mcp?.summary() || []) {
      if (server.status === 'error') ui.warn(`MCP ${server.name}: ${server.error}`);
    }
  }

  async function expandMentions(text) {
    const attachments = [];
    const seen = new Set();
    let total = 0;
    const replaced = String(text).replace(/(^|[\s(])@([^\s@]+)/g, (whole, prefix, rawPath) => {
      const trailing = rawPath.match(/[.,;:!?)]+$/)?.[0] || '';
      const cleaned = rawPath.slice(0, rawPath.length - trailing.length);
      if (!cleaned || cleaned.includes('://')) return whole;
      const filePath = path.resolve(cwd, expandHome(cleaned));
      if (seen.has(filePath) || total > 240000) return whole;
      let stat;
      try {
        stat = fs.statSync(filePath);
      } catch {
        return whole;
      }
      if (!stat.isFile()) return whole;
      const ext = path.extname(filePath).toLowerCase();
      const relative = path.relative(cwd, filePath) || filePath;
      if (IMAGE_TYPES[ext]) {
        if (stat.size > 5 * 1024 * 1024) return whole;
        const data = fs.readFileSync(filePath).toString('base64');
        seen.add(filePath);
        total += data.length;
        attachments.push({
          type: 'image',
          source: { type: 'base64', media_type: IMAGE_TYPES[ext], data },
        });
        return `${prefix}@${cleaned}${trailing}`;
      }
      if (stat.size > 2 * 1024 * 1024) return whole;
      const buffer = fs.readFileSync(filePath);
      if (isProbablyBinary(buffer)) return whole;
      const content = readCapped(filePath, 60000);
      seen.add(filePath);
      total += content.length;
      attachments.push({
        type: 'text',
        text: `<attached-file path="${relative}">\n${content}\n</attached-file>`,
      });
      return `${prefix}@${cleaned}${trailing}`;
    });
    return { text: replaced, attachments };
  }

  async function sendPrompt(text) {
    if (!String(text || '').trim()) return { empty: true };
    const controller = new AbortController();
    runtime.controller = controller;
    const onSigint = () => {
      if (!controller.signal.aborted) {
        ui.warn('\nInterrupting…');
        controller.abort();
      }
    };
    process.on('SIGINT', onSigint);

    try {
      const expanded = await expandMentions(text);
      const hookResults = await runHooks(
        'UserPromptSubmit',
        {
          prompt: expanded.text,
          session_id: session.id,
          cwd,
          model: runtime.modelInfo.id,
        },
        config,
        { signal: controller.signal }
      );
      const blocked = hookResults.find((result) => result.blocked);
      if (blocked) {
        ui.warn(`Prompt blocked by UserPromptSubmit hook: ${blocked.reason || 'blocked'}`);
        return { blocked: true };
      }
      const hookContext = collectHookContext(hookResults);
      const content = [{ type: 'text', text: expanded.text }];
      if (hookContext) content.push({ type: 'text', text: `[Hook context]\n${hookContext}` });
      content.push(...expanded.attachments);
      session.messages.push({ role: 'user', content });
      session.touchTitle(text);

      const result = await runtime.agent.runTurn(null, { signal: controller.signal });
      session.save();

      if (ui.mode === 'json') {
        jsonLine({
          type: 'result',
          subtype: 'success',
          result: result.text,
          session_id: session.id,
          provider: runtime.provider.name,
          model: runtime.modelInfo.id,
          turns: result.turns,
          usage: {
            ...result.usage,
            session: session.usage,
          },
        });
      } else if (ui.mode !== 'interactive') {
        ui.printFinal(result.text);
      }
      return result;
    } catch (err) {
      const message = err?.message || String(err);
      try {
        session.save();
      } catch {}
      if (err?.name === 'AbortError') {
        ui.notice('Interrupted.');
        if (ui.mode === 'json') {
          jsonLine({ type: 'result', subtype: 'interrupted', result: '', session_id: session.id });
        }
        return { aborted: true };
      }
      ui.error(message);
      if (ui.mode === 'json') {
        jsonLine({
          type: 'result',
          subtype: 'error',
          error: message,
          session_id: session.id,
          provider: runtime.provider.name,
          model: runtime.modelInfo.id,
        });
      }
      return { error: message };
    } finally {
      process.removeListener('SIGINT', onSigint);
      runtime.controller = null;
      ui.stopSpinner();
    }
  }

  async function runShellLine(line) {
    const command = line.slice(1).trim();
    if (!command) return;
    const result = await bashTool.run(
      { command },
      {
        cwd,
        config,
        session,
        signal: runtime.controller?.signal,
        ui,
      }
    );
    const output = typeof result.output === 'string' ? result.output : '';
    ui.line(ui.dim(`! ${command}`));
    if (output) ui.line(output);
    session.messages.push({
      role: 'user',
      content: [
        {
          type: 'text',
          text: `[User ran a shell command]\n$ ${command}\n\n${truncateText(output, 20000)}`,
        },
      ],
    });
    session.save();
  }

  async function runRepl(initialPrompt = null) {
    if (initialPrompt) {
      const result = await sendPrompt(initialPrompt);
      if (result?.error || result?.aborted) {
        if (ui.mode !== 'interactive') return result?.aborted ? 130 : 1;
      }
    }
    for (;;) {
      if (runtime.exitRequested) break;
      const input = await prompter.readInput(`${ui.cyan('›')} `);
      if (input === null) break;
      if (input === undefined) {
        ui.line(ui.dim('Ctrl+C again or /exit to quit.'));
        continue;
      }
      const line = input.trim();
      if (!line) continue;

      if (line.startsWith('/')) {
        let result;
        try {
          result = await handleCommand(line, runtime);
        } catch (err) {
          ui.error(err.message);
          continue;
        }
        if (result.type === 'exit') break;
        if (result.type === 'prompt') {
          const sent = await sendPrompt(result.text);
          if (sent?.error || sent?.aborted) {
            if (ui.mode !== 'interactive') return sent?.aborted ? 130 : 1;
          }
        }
        session.save();
        continue;
      }

      if (line.startsWith('!') && ui.mode === 'interactive') {
        await runShellLine(line);
        continue;
      }

      const sent = await sendPrompt(line);
      if (sent?.error || sent?.aborted) {
        if (ui.mode !== 'interactive') return sent?.aborted ? 130 : 1;
      }
      session.save();
    }
    return 0;
  }

  let cleanedUp = false;
  const cleanup = () => {
    if (cleanedUp) return;
    cleanedUp = true;
    try {
      runtime.mcp?.close();
    } catch {}
    try {
      prompter.close();
    } catch {}
    try {
      if (session) session.save();
    } catch {}
  };
  process.once('SIGTERM', () => {
    cleanup();
    process.exit(143);
  });

  try {
    if (prompt && !options.repl) {
      const result = await sendPrompt(prompt);
      session.save();
      if (result?.aborted) return 130;
      if (result?.error) return 1;
      return 0;
    }
    return await runRepl(options.repl ? prompt : null);
  } finally {
    cleanup();
  }
}

export { loadConfig, saveConfig, CONFIG_PATH };
