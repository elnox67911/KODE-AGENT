import { newId } from '../utils.js';
import { postStream, ProviderError, sseEvents } from './http.js';

function imagePart(block) {
  return {
    type: 'image_url',
    image_url: { url: `data:${block.source?.media_type || 'image/png'};base64,${block.source?.data || ''}` },
  };
}

export function toOpenAIMessages(system, messages) {
  const out = [];
  if (system) out.push({ role: 'system', content: system });
  for (const message of messages) {
    if (message.role === 'assistant') {
      const texts = [];
      const toolCalls = [];
      for (const block of message.content || []) {
        if (block.type === 'text' && block.text) texts.push(block.text);
        else if (block.type === 'tool_use') {
          toolCalls.push({
            id: block.id,
            type: 'function',
            function: { name: block.name, arguments: JSON.stringify(block.input ?? {}) },
          });
        }
      }
      const entry = { role: 'assistant', content: texts.join('') || null };
      if (toolCalls.length) entry.tool_calls = toolCalls;
      out.push(entry);
      continue;
    }

    const toolResults = (message.content || []).filter((block) => block.type === 'tool_result');
    const otherBlocks = (message.content || []).filter((block) => block.type !== 'tool_result');
    const trailingImages = [];

    for (const block of toolResults) {
      let text = '';
      if (typeof block.content === 'string') text = block.content;
      else if (Array.isArray(block.content)) {
        for (const part of block.content) {
          if (part.type === 'text') text += `${text ? '\n' : ''}${part.text}`;
          else if (part.type === 'image') trailingImages.push(part);
        }
      }
      if (block.is_error) text = `[tool error] ${text}`;
      out.push({ role: 'tool', tool_call_id: block.tool_use_id, content: text || '(no output)' });
    }

    const parts = [];
    for (const block of otherBlocks) {
      if (block.type === 'text' && block.text) parts.push({ type: 'text', text: block.text });
      else if (block.type === 'image') trailingImages.push(block);
    }
    for (const block of trailingImages) parts.push(imagePart(block));
    if (parts.length) {
      out.push({
        role: 'user',
        content: parts.length === 1 && parts[0].type === 'text' ? parts[0].text : parts,
      });
    }
  }
  return out;
}

function toOpenAITools(tools) {
  return (tools || []).map((tool) => ({
    type: 'function',
    function: {
      name: tool.name,
      description: tool.description,
      parameters: tool.inputSchema || { type: 'object', properties: {} },
    },
  }));
}

async function openStream(provider, body, signal) {
  let compatAttempts = 0;
  for (;;) {
    try {
      return await postStream(`${provider.baseURL}/chat/completions`, {
        headers: {
          authorization: `Bearer ${provider.apiKey || ''}`,
          ...provider.headers,
        },
        body,
        signal,
        label: `${provider.label} chat`,
      });
    } catch (err) {
      if (err.status === 400 && compatAttempts < 2) {
        const text = String(err.body || '');
        if (body.stream_options && /stream_options|include_usage/i.test(text)) {
          delete body.stream_options;
          compatAttempts++;
          continue;
        }
        if (body.max_completion_tokens && /max_completion_tokens/i.test(text)) {
          body.max_tokens = body.max_completion_tokens;
          delete body.max_completion_tokens;
          compatAttempts++;
          continue;
        }
      }
      throw err;
    }
  }
}

export async function* streamChat({ provider, model, system, messages, tools, maxTokens, temperature, signal }) {
  const reasoningModel = /^(o1|o3|o4|gpt-5)/i.test(model);
  const body = {
    model,
    messages: toOpenAIMessages(system, messages),
    stream: true,
    stream_options: { include_usage: true },
  };
  if (tools?.length) body.tools = toOpenAITools(tools);
  if (maxTokens) {
    if (reasoningModel) body.max_completion_tokens = maxTokens;
    else body.max_tokens = maxTokens;
  }
  if (temperature !== null && temperature !== undefined && !reasoningModel) body.temperature = temperature;

  const res = await openStream(provider, body, signal);

  let text = '';
  const toolCalls = new Map();
  const usage = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 };
  let finishReason = null;

  for await (const entry of sseEvents(res.body)) {
    if (entry.done) break;
    const evt = entry.data;
    if (evt.error) {
      const detail = evt.error?.message || (typeof evt.error === 'string' ? evt.error : JSON.stringify(evt.error));
      throw new ProviderError(`${provider.label} stream error: ${detail}`, { body: detail });
    }
    if (evt.usage) {
      usage.input = evt.usage.prompt_tokens ?? evt.usage.input_tokens ?? usage.input;
      usage.output = evt.usage.completion_tokens ?? evt.usage.output_tokens ?? usage.output;
      usage.cacheRead = evt.usage.prompt_tokens_details?.cached_tokens || evt.usage.cache_read_input_tokens || 0;
    }
    const choice = evt.choices?.[0];
    if (!choice) continue;
    const delta = choice.delta || {};

    if (typeof delta.content === 'string' && delta.content) {
      text += delta.content;
      yield { type: 'text_delta', text: delta.content };
    } else if (Array.isArray(delta.content)) {
      for (const part of delta.content) {
        if (part?.type === 'text' && part.text) {
          text += part.text;
          yield { type: 'text_delta', text: part.text };
        }
      }
    }
    const reasoning = delta.reasoning_content || delta.reasoning;
    if (typeof reasoning === 'string' && reasoning) {
      yield { type: 'reasoning_delta', text: reasoning };
    }

    if (Array.isArray(delta.tool_calls)) {
      for (const call of delta.tool_calls) {
        const index = call.index ?? 0;
        let entryCall = toolCalls.get(index);
        if (!entryCall) {
          entryCall = { id: '', name: '', args: '', announced: false };
          toolCalls.set(index, entryCall);
        }
        if (call.id) entryCall.id = call.id;
        if (call.function?.name) entryCall.name = call.function.name;
        if (call.function?.arguments) entryCall.args += call.function.arguments;
        if (entryCall.name && !entryCall.announced) {
          entryCall.announced = true;
          yield { type: 'tool_start', id: entryCall.id || '', name: entryCall.name };
        }
      }
    }
    if (choice.finish_reason) finishReason = choice.finish_reason;
  }

  const content = [];
  if (text) content.push({ type: 'text', text });
  for (const [, call] of [...toolCalls.entries()].sort((a, b) => a[0] - b[0])) {
    if (!call.name) continue;
    let input = {};
    let invalid = false;
    if (call.args.trim()) {
      try {
        input = JSON.parse(call.args);
      } catch {
        invalid = true;
      }
    }
    const toolUse = { type: 'tool_use', id: call.id || newId('call'), name: call.name, input };
    if (invalid) toolUse._invalid = true;
    content.push(toolUse);
  }

  yield {
    type: 'done',
    message: { role: 'assistant', content },
    usage,
    stopReason: finishReason,
  };
}
