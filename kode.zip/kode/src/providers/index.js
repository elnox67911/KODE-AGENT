import * as anthropic from './anthropic.js';
import * as openai from './openai.js';
import * as google from './google.js';
import { fetchJSON, friendlyProviderError, ProviderError } from './http.js';

export { friendlyProviderError, ProviderError };

export function chatStream({ config, provider, modelInfo, system, messages, tools, signal }) {
  const impl =
    provider.type === 'anthropic' ? anthropic : provider.type === 'google' ? google : openai;
  const maxOutput = Math.max(
    1,
    Math.min(config.maxTokens || 8192, modelInfo?.maxOutput || config.maxTokens || 8192)
  );
  return impl.streamChat({
    provider,
    model: modelInfo?.id || config.model,
    system,
    messages,
    tools,
    maxTokens: maxOutput,
    temperature: config.temperature,
    signal,
  });
}

export async function listRemoteModels(provider, { timeoutMs = 5000 } = {}) {
  if (!provider.baseURL || provider.type !== 'openai') return [];
  const json = await fetchJSON(`${provider.baseURL}/models`, {
    headers: {
      authorization: `Bearer ${provider.apiKey || ''}`,
      ...provider.headers,
    },
    timeoutMs,
  });
  const items = json.data || json.models || [];
  return items
    .map((item) => (typeof item === 'string' ? item : item.id || item.name || '').replace(/^models\//, ''))
    .filter(Boolean);
}
