import { postStream, ProviderError, sseEvents } from './http.js';

function cleanBlock(block) {
  if (!block) return null;
  if (block.type === 'text') {
    return block.text ? { type: 'text', text: block.text } : null;
  }
  if (block.type === 'image') {
    return { type: 'image', source: block.source };
  }
  if (block.type === 'tool_use') {
    return { type: 'tool_use', id: block.id, name: block.name, input: block.input || {} };
  }
  if (block.type === 'tool_result') {
    const result = { type: 'tool_result', tool_use_id: block.tool_use_id, content: block.content ?? '' };
    if (block.is_error) result.is_error = true;
    return result;
  }
  return null;
}

export function toAnthropicMessages(messages) {
  const out = [];
  for (const message of messages) {
    const content = (message.content || []).map(cleanBlock).filter(Boolean);
    if (content.length) out.push({ role: message.role, content });
  }
  return out;
}

function toAnthropicTools(tools) {
  return (tools || []).map((tool) => ({
    name: tool.name,
    description: tool.description,
    input_schema: tool.inputSchema || { type: 'object', properties: {} },
  }));
}

export async function* streamChat({
  provider,
  model,
  system,
  messages,
  tools,
  maxTokens,
  temperature,
  signal,
}) {
  const body = {
    model,
    max_tokens: Math.max(1, Math.floor(maxTokens || 8192)),
    messages: toAnthropicMessages(messages),
    stream: true,
  };
  if (system) {
    body.system = [{ type: 'text', text: system, cache_control: { type: 'ephemeral' } }];
  }
  if (tools?.length) body.tools = toAnthropicTools(tools);
  if (temperature !== null && temperature !== undefined) body.temperature = temperature;

  const res = await postStream(`${provider.baseURL}/v1/messages`, {
    headers: {
      'x-api-key': provider.apiKey || '',
      'anthropic-version': '2023-06-01',
      ...provider.headers,
    },
    body,
    signal,
    label: `${provider.label} messages`,
  });

  const usage = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 };
  const blocks = [];
  let stopReason = null;

  for await (const entry of sseEvents(res.body)) {
    if (entry.done) break;
    const evt = entry.data;
    const type = evt.type;
    if (type === 'message_start') {
      const u = evt.message?.usage || {};
      usage.input = u.input_tokens || 0;
      usage.output = u.output_tokens || 0;
      usage.cacheRead = u.cache_read_input_tokens || 0;
      usage.cacheWrite = u.cache_creation_input_tokens || 0;
    } else if (type === 'content_block_start') {
      const cb = evt.content_block || {};
      if (cb.type === 'tool_use') {
        blocks[evt.index] = {
          kind: 'tool_use',
          id: cb.id,
          name: cb.name,
          json: '',
        };
        yield { type: 'tool_start', id: cb.id, name: cb.name };
      } else if (cb.type === 'thinking') {
        blocks[evt.index] = { kind: 'thinking', text: cb.thinking || '' };
        if (cb.thinking) yield { type: 'reasoning_delta', text: cb.thinking };
      } else {
        blocks[evt.index] = { kind: 'text', text: cb.text || '' };
        if (cb.text) yield { type: 'text_delta', text: cb.text };
      }
    } else if (type === 'content_block_delta') {
      const delta = evt.delta || {};
      const block = blocks[evt.index];
      if (!block) continue;
      if (delta.type === 'text_delta') {
        block.text += delta.text || '';
        if (delta.text) yield { type: 'text_delta', text: delta.text };
      } else if (delta.type === 'thinking_delta') {
        block.text += delta.thinking || '';
        if (delta.thinking) yield { type: 'reasoning_delta', text: delta.thinking };
      } else if (delta.type === 'input_json_delta') {
        block.json += delta.partial_json || '';
      }
    } else if (type === 'message_delta') {
      if (evt.usage?.output_tokens != null) usage.output = evt.usage.output_tokens;
      if (evt.delta?.stop_reason) stopReason = evt.delta.stop_reason;
    } else if (type === 'error') {
      throw new ProviderError(`Anthropic stream error: ${evt.error?.message || 'unknown'}`, {
        body: JSON.stringify(evt.error || {}),
      });
    }
  }

  const content = [];
  for (const block of blocks) {
    if (!block) continue;
    if (block.kind === 'text') {
      if (block.text) content.push({ type: 'text', text: block.text });
    } else if (block.kind === 'tool_use') {
      let input = {};
      let invalid = false;
      try {
        input = block.json ? JSON.parse(block.json) : {};
      } catch {
        invalid = true;
      }
      const toolUse = { type: 'tool_use', id: block.id, name: block.name, input };
      if (invalid) toolUse._invalid = true;
      content.push(toolUse);
    }
  }

  yield {
    type: 'done',
    message: { role: 'assistant', content },
    usage,
    stopReason,
  };
}
