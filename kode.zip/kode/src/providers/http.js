import { safeJsonParse, sleep } from '../utils.js';

export class ProviderError extends Error {
  constructor(message, { status, body, retryAfter } = {}) {
    super(message);
    this.name = 'ProviderError';
    this.status = status;
    this.body = body;
    this.retryAfter = retryAfter;
  }
}

function isRetryableStatus(status) {
  return status === 408 || status === 409 || status === 425 || status === 429 || status >= 500;
}

function isNetworkError(err) {
  if (!err) return false;
  const code = err.cause?.code || err.code;
  if (['ECONNREFUSED', 'ECONNRESET', 'ENOTFOUND', 'ETIMEDOUT', 'EAI_AGAIN', 'EPIPE', 'UND_ERR_SOCKET'].includes(code)) {
    return true;
  }
  return /fetch failed|network|socket|connection/i.test(err.message || '');
}

function retryAfterMs(res) {
  const header = res.headers?.get?.('retry-after');
  if (!header) return null;
  const seconds = Number(header);
  if (Number.isFinite(seconds)) return Math.min(seconds * 1000, 30000);
  const date = Date.parse(header);
  if (Number.isFinite(date)) return Math.max(0, Math.min(date - Date.now(), 30000));
  return null;
}

export async function postStream(url, { headers = {}, body, signal, retries = 2, label = 'request' } = {}) {
  let attempt = 0;
  for (;;) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...headers },
        body: JSON.stringify(body),
        signal,
      });
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        const error = new ProviderError(`${label} failed with HTTP ${res.status}`, {
          status: res.status,
          body: text,
          retryAfter: retryAfterMs(res),
        });
        if (isRetryableStatus(res.status) && attempt < retries) {
          const wait = error.retryAfter ?? Math.min(1000 * 2 ** attempt, 8000);
          attempt++;
          await sleep(wait, signal);
          continue;
        }
        throw error;
      }
      return res;
    } catch (err) {
      if (err?.name === 'AbortError') throw err;
      if (err instanceof ProviderError) throw err;
      if (isNetworkError(err) && attempt < retries) {
        attempt++;
        await sleep(Math.min(1000 * 2 ** attempt, 8000), signal);
        continue;
      }
      throw new ProviderError(`${label} failed: ${err?.message || err}`, { body: String(err?.cause || '') });
    }
  }
}

export async function fetchJSON(url, { headers = {}, signal, timeoutMs = 15000 } = {}) {
  const controller = new AbortController();
  const onAbort = () => controller.abort(signal?.reason);
  if (signal) {
    if (signal.aborted) throw new Error('aborted');
    signal.addEventListener('abort', onAbort, { once: true });
  }
  const timer = setTimeout(() => controller.abort(new Error('timeout')), timeoutMs);
  try {
    const res = await fetch(url, { headers, signal: controller.signal });
    const text = await res.text();
    const json = safeJsonParse(text);
    if (!res.ok) {
      throw new ProviderError(`HTTP ${res.status}`, { status: res.status, body: text, retryAfter: retryAfterMs(res) });
    }
    if (!json) throw new ProviderError('Response was not valid JSON', { body: text.slice(0, 500) });
    return json;
  } finally {
    clearTimeout(timer);
    if (signal) signal.removeEventListener('abort', onAbort);
  }
}

export async function* sseEvents(body) {
  const decoder = new TextDecoder();
  let buffer = '';
  let dataLines = [];
  const flushData = function* () {
    if (!dataLines.length) return;
    const data = dataLines.join('\n');
    dataLines = [];
    if (!data || data === '[DONE]') {
      if (data === '[DONE]') yield { done: true, data: null };
      return;
    }
    const json = safeJsonParse(data, null);
    if (json === null) return;
    yield { done: false, data: json };
  };
  for await (const chunk of body) {
    buffer += decoder.decode(chunk, { stream: true });
    let newline;
    while ((newline = buffer.indexOf('\n')) !== -1) {
      let line = buffer.slice(0, newline);
      buffer = buffer.slice(newline + 1);
      line = line.replace(/\r$/, '');
      if (line === '') {
        yield* flushData();
        continue;
      }
      if (line.startsWith(':')) continue;
      if (line.startsWith('data:')) {
        dataLines.push(line.slice(5).replace(/^ /, ''));
        continue;
      }
      if (line.startsWith('event:') || line.startsWith('id:') || line.startsWith('retry:')) continue;
      // Some proxies send raw JSON lines without the data: prefix.
      if (line.startsWith('{') || line.startsWith('[')) {
        const json = safeJsonParse(line, null);
        if (json) yield { done: false, data: json };
      }
    }
  }
  buffer += decoder.decode();
  if (buffer.trim()) {
    let line = buffer.replace(/\r$/, '');
    if (line.startsWith('data:')) dataLines.push(line.slice(5).replace(/^ /, ''));
    else if (line.startsWith('{') || line.startsWith('[')) {
      const json = safeJsonParse(line, null);
      if (json) yield { done: false, data: json };
    }
  }
  yield* flushData();
}

export function extractErrorMessage(bodyText) {
  const json = safeJsonParse(bodyText);
  if (json) {
    const candidates = [
      json.error?.message,
      json.error?.error?.message,
      typeof json.error === 'string' ? json.error : null,
      json.message,
      json.error_description,
      json.detail,
    ].filter(Boolean);
    if (candidates.length) return candidates[0];
  }
  return String(bodyText || '').slice(0, 400);
}

export function friendlyProviderError(err, provider) {
  if (err?.name === 'AbortError') return 'Request interrupted.';
  if (err instanceof ProviderError) {
    const detail = extractErrorMessage(err.body);
    const prefix = provider ? `${provider.label || provider.name}` : 'Provider';
    if (err.status === 401 || err.status === 403) {
      return `${prefix} rejected the API key (${err.status}). Run /setup to update your key.${detail ? `\n${detail}` : ''}`;
    }
    if (err.status === 404) {
      return `${prefix} returned 404. Check the model name and base URL.${detail ? `\n${detail}` : ''}`;
    }
    if (err.status === 429) {
      return `${prefix} rate limited the request. Wait a moment or switch models.${detail ? `\n${detail}` : ''}`;
    }
    if (err.status >= 500) {
      return `${prefix} is having trouble (HTTP ${err.status}).${detail ? `\n${detail}` : ''}`;
    }
    return `${prefix} error (HTTP ${err.status || '?'}).${detail ? `\n${detail}` : ''}`;
  }
  return err?.message || String(err);
}
