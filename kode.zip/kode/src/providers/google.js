import { newId } from '../utils.js';
import { postStream, ProviderError, sseEvents } from './http.js';

export function cleanSchema(schema) {
  if (Array.isArray(schema)) return schema.map(cleanSchema);
  if (!schema || typeof schema !== 'object') return schema;
  const out = {};
  for (const [key, value] of Object.entries(schema)) {
    if (['additionalProperties', '$schema', '$id', '$ref', 'definitions', 'examples', 'default'].includes(key)) continue;
    out[key] = cleanSchema(value);
  }
  return out;
}

export function toGoogleContents(messages) {
  const contents = [];
  const toolNameById = new Map();
  let pendingNames = [];
  let lastName = 'tool';

  const push = (role, parts) => {
    if (!parts.length) return;
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts.push(...parts);
    else contents.push({ role, parts });
  };

  for (const message of messages) {
    if (message.role === 'assistant') {
      const parts = [];
      pendingNames = [];
      for (const block of message.content || []) {
        if (block.type === 'text' && block.text) parts.push({ text: block.text });
        else if (block.type === 'tool_use') {
          const call = { name: block.name, args: block.input || {} };
          if (block.id) {
            call.id = block.id;
            toolNameById.set(block.id, block.name);
          }
          lastName = block.name;
          pendingNames.push(block.name);
          parts.push({ functionCall: call });
        }
      }
      push('model', parts);
      continue;
    }

    const toolResults = (message.content || []).filter((block) => block.type === 'tool_result');
    const parts = [];
    const images = [];
    for (const block of toolResults) {
      let text = '';
      if (typeof block.content === 'string') text = block.content;
      else if (Array.isArray(block.content)) {
        for (const part of block.content) {
          if (part.type === 'text') text += `${text ? '\n' : ''}${part.text}`;
          else if (part.type === 'image') images.push(part);
        }
      }
      const name = toolNameById.get(block.tool_use_id) || pendingNames.shift() || lastName;
      const response = { result: text || '' };
      if (block.is_error) response.error = text || 'tool failed';
      const functionResponse = { name, response };
      if (block.tool_use_id) functionResponse.id = block.tool_use_id;
      parts.push({ functionResponse });
    }
    for (const block of message.content || []) {
      if (block.type === 'text' && block.text) parts.push({ text: block.text });
      else if (block.type === 'image' && block.source?.data) {
        images.push(block);
      }
    }
    for (const block of images) {
      parts.push({ inlineData: { mimeType: block.source.media_type || 'image/png', data: block.source.data } });
    }
    push('user', parts);
  }
  return contents;
}

function toGoogleTools(tools) {
  return [
    {
      functionDeclarations: (tools || []).map((tool) => ({
        name: tool.name,
        description: tool.description,
        parameters: cleanSchema(tool.inputSchema || { type: 'object', properties: {} }),
      })),
    },
  ];
}

export async function* streamChat({ provider, model, system, messages, tools, maxTokens, temperature, signal }) {
  const url = `${provider.baseURL}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
  const body = {
    contents: toGoogleContents(messages),
    generationConfig: {
      maxOutputTokens: Math.max(1, Math.floor(maxTokens || 8192)),
      ...(temperature !== null && temperature !== undefined ? { temperature } : {}),
    },
  };
  if (system) body.systemInstruction = { parts: [{ text: system }] };
  if (tools?.length) body.tools = toGoogleTools(tools);

  const res = await postStream(url, {
    headers: {
      'x-goog-api-key': provider.apiKey || '',
      ...provider.headers,
    },
    body,
    signal,
    label: `${provider.label} generateContent`,
  });

  let text = '';
  const calls = [];
  const seenCalls = new Set();
  const usage = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 };
  let finishReason = null;
  let blockReason = null;

  for await (const entry of sseEvents(res.body)) {
    if (entry.done) break;
    const evt = entry.data;
    if (evt.error) {
      throw new ProviderError(`Google stream error: ${evt.error?.message || 'unknown'}`, {
        body: JSON.stringify(evt.error || {}),
      });
    }
    if (evt.promptFeedback?.blockReason) blockReason = evt.promptFeedback.blockReason;
    const meta = evt.usageMetadata;
    if (meta) {
      usage.input = meta.promptTokenCount ?? usage.input;
      usage.output = meta.candidatesTokenCount ?? usage.output;
      usage.cacheRead = meta.cachedContentTokenCount || 0;
    }
    const candidate = evt.candidates?.[0];
    if (!candidate) continue;
    if (candidate.finishReason) finishReason = candidate.finishReason;
    for (const part of candidate.content?.parts || []) {
      if (part.text) {
        if (part.thought) {
          yield { type: 'reasoning_delta', text: part.text };
        } else {
          text += part.text;
          yield { type: 'text_delta', text: part.text };
        }
      }
      if (part.functionCall) {
        const call = part.functionCall;
        const key = `${call.name}:${JSON.stringify(call.args || {})}:${call.id || ''}`;
        if (seenCalls.has(key)) continue;
        seenCalls.add(key);
        const id = call.id || newId('call');
        calls.push({ type: 'tool_use', id, name: call.name, input: call.args || {} });
        yield { type: 'tool_start', id, name: call.name };
      }
    }
  }

  if (blockReason) {
    throw new ProviderError(`Google blocked the request: ${blockReason}`);
  }

  const content = [];
  if (text) content.push({ type: 'text', text });
  content.push(...calls);

  const stopReason =
    finishReason === 'MAX_TOKENS'
      ? 'max_tokens'
      : finishReason === 'SAFETY' || finishReason === 'RECITATION'
        ? 'refusal'
        : finishReason === 'STOP'
          ? 'end_turn'
          : finishReason;

  yield {
    type: 'done',
    message: { role: 'assistant', content },
    usage,
    stopReason,
  };
}
