import { firstLine, formatCost, formatTokens, stripAnsi, truncateText } from '../utils.js';

const CODES = {
  reset: '0',
  bold: '1',
  dim: '2',
  italic: '3',
  underline: '4',
  red: '31',
  green: '32',
  yellow: '33',
  blue: '34',
  magenta: '35',
  cyan: '36',
  gray: '90',
  brightWhite: '97',
};

const SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];

export class UI {
  constructor({ mode = 'interactive', color = true, verbose = false, spinner = true } = {}) {
    this.mode = mode;
    this.verbose = verbose;
    this.colorEnabled =
      color &&
      mode !== 'json' &&
      !process.env.NO_COLOR &&
      process.env.FORCE_COLOR !== '0' &&
      (mode === 'interactive' ? process.stdout.isTTY !== false : process.stderr.isTTY !== false);
    this.spinnerEnabled =
      spinner && mode === 'interactive' && process.stdout.isTTY && process.env.KODE_NO_SPINNER !== '1';
    this.spinnerTimer = null;
    this.spinnerLabel = '';
    this.spinnerFrame = 0;
    this.renderer = null;
    this.silentDepth = 0;
  }

  paint(name, text) {
    if (!this.colorEnabled) return String(text);
    const code = CODES[name];
    if (!code) return String(text);
    return `\x1b[${code}m${text}\x1b[0m`;
  }

  bold(text) {
    return this.paint('bold', text);
  }

  dim(text) {
    return this.paint('dim', text);
  }

  italic(text) {
    return this.paint('italic', text);
  }

  cyan(text) {
    return this.paint('cyan', text);
  }

  green(text) {
    return this.paint('green', text);
  }

  yellow(text) {
    return this.paint('yellow', text);
  }

  red(text) {
    return this.paint('red', text);
  }

  magenta(text) {
    return this.paint('magenta', text);
  }

  raw(text) {
    if (this.mode === 'json') return;
    if (this.silentDepth > 0) return;
    process.stdout.write(text);
  }

  chrome(text, { force = false } = {}) {
    if (this.mode === 'json') return;
    if (this.silentDepth > 0) return;
    if (this.mode === 'interactive') process.stdout.write(text);
    else if (force || this.verbose) process.stderr.write(stripAnsi(text));
  }

  line(text = '', options) {
    this.chrome(`${text}\n`, options);
  }

  info(text) {
    if (this.mode === 'interactive') this.line(this.dim(text));
    else if (this.verbose) this.chrome(`${stripAnsi(text)}\n`);
  }

  notice(text) {
    this.chrome(`${text}\n`, { force: true });
  }

  warn(text) {
    if (this.mode === 'json') return;
    process.stderr.write(`${this.paint('yellow', text)}\n`);
  }

  error(text) {
    if (this.mode === 'json') return;
    process.stderr.write(`${this.paint('red', text)}\n`);
  }

  success(text) {
    if (this.mode === 'interactive') this.line(this.green(text));
    else if (this.verbose) process.stderr.write(`${stripAnsi(text)}\n`);
  }

  banner({ provider, model, cwd, version, sessionId }) {
    if (this.mode !== 'interactive') return;
    this.line('');
    this.line(`  ${this.bold('kode')} ${this.dim(`v${version}`)}  ${this.dim('·')}  ${this.dim('BYOK coding agent')}`);
    this.line(`  ${this.cyan(`${provider}/${model}`)}  ${this.dim('·')}  ${this.dim(cwd)}`);
    this.line(`  ${this.dim(`session ${sessionId}`)}  ${this.dim('·')}  ${this.dim('/help for commands, /exit to quit')}`);
    this.line('');
  }

  startSpinner(label = 'working') {
    if (!this.spinnerEnabled || this.silentDepth > 0) return;
    this.stopSpinner();
    this.spinnerLabel = label;
    this.spinnerFrame = 0;
    const tick = () => {
      const frame = SPINNER_FRAMES[this.spinnerFrame++ % SPINNER_FRAMES.length];
      process.stderr.write(`\r\x1b[2K${this.paint('dim', `${frame} ${this.spinnerLabel}`)}`);
    };
    tick();
    this.spinnerTimer = setInterval(tick, 90);
    this.spinnerTimer.unref?.();
  }

  stopSpinner() {
    if (this.spinnerTimer) {
      clearInterval(this.spinnerTimer);
      this.spinnerTimer = null;
      process.stderr.write('\r\x1b[2K');
    }
  }

  beginAssistant() {
    this.stopSpinner();
    if (this.silentDepth > 0) {
      this.renderer = null;
      return;
    }
    this.renderer = new MarkdownRenderer(this);
  }

  assistantText(text) {
    if (!text) return;
    if (this.mode !== 'interactive' || this.silentDepth > 0) return;
    this.stopSpinner();
    this.renderer.write(text);
  }

  reasoningText(text) {
    if (this.mode !== 'interactive' || this.silentDepth > 0 || !text) return;
    this.stopSpinner();
    process.stdout.write(this.paint('dim', text));
  }

  endAssistant() {
    if (this.mode === 'interactive' && this.renderer) {
      this.renderer.end();
      this.renderer = null;
    }
  }

  toolStart(name, summary) {
    this.stopSpinner();
    if (this.mode === 'json' || this.silentDepth > 0) return;
    const label = summary ? `${name}(${truncateText(summary, 110)})` : name;
    if (this.mode === 'interactive') {
      this.line(`${this.cyan('●')} ${this.bold(label)}`);
    } else if (this.verbose) {
      process.stderr.write(`${label}\n`);
    }
  }

  toolResult({ name, isError, summary, preview, diff, stats }) {
    this.stopSpinner();
    if (this.mode === 'json' || this.silentDepth > 0) return;
    const marker = isError ? this.red('⎿') : this.dim('⎿');
    const text = summary || (isError ? 'failed' : 'done');
    if (this.mode === 'interactive') {
      this.line(`  ${marker} ${isError ? this.red(text) : this.dim(text)}`);
      if (diff?.length) this.renderDiff(diff, stats);
      if (preview) this.renderPreview(preview, isError);
    } else if (this.verbose) {
      process.stderr.write(`  ${isError ? '[error] ' : ''}${stripAnsi(text)}\n`);
      if (preview) process.stderr.write(`${truncateText(stripAnsi(preview), 3000)}\n`);
    }
  }

  renderPreview(preview, isError) {
    const lines = String(preview).split('\n');
    const shown = this.verbose ? 30 : 10;
    const body = lines.slice(0, shown);
    for (const line of body) {
      this.line(`     ${isError ? this.red(line) : this.dim(line)}`);
    }
    if (lines.length > shown) {
      this.line(`     ${this.dim(`… ${lines.length - shown} more lines`)}`);
    }
  }

  renderDiff(ops, stats) {
    if (!ops || !ops.length) return;
    const indices = new Set();
    for (let i = 0; i < ops.length; i++) {
      if (ops[i].type === 'same') continue;
      const from = Math.max(0, i - 2);
      const to = Math.min(ops.length - 1, i + 2);
      for (let j = from; j <= to; j++) indices.add(j);
    }
    const picked = [...indices].sort((a, b) => a - b);
    const capped = picked.slice(0, this.verbose ? 160 : 60);
    let last = -1;
    for (const index of capped) {
      if (last !== -1 && index > last + 1) this.line(`     ${this.dim('⋯')}`);
      const op = ops[index];
      if (op.type === 'add') this.line(`     ${this.green(`+ ${op.line}`)}`);
      else if (op.type === 'del') this.line(`     ${this.red(`- ${op.line}`)}`);
      else this.line(`     ${this.dim(`  ${op.line}`)}`);
      last = index;
    }
    if (picked.length > capped.length) {
      this.line(`     ${this.dim(`… ${picked.length - capped.length} more diff lines`)}`);
    }
    if (stats) this.line(`     ${this.dim(`(${stats.add} added, ${stats.del} removed)`)}`);
  }

  compacted({ before, after, tokensBefore, tokensAfter }) {
    this.stopSpinner();
    if (this.silentDepth > 0) return;
    if (this.mode !== 'interactive') {
      if (this.verbose) process.stderr.write(`Context compacted: ${before} -> ${after} messages\n`);
      return;
    }
    this.line(
      `  ${this.magenta('✦')} ${this.dim(`compacted context: ${before} → ${after} messages`)}` +
        (tokensBefore ? ` ${this.dim(`(~${formatTokens(tokensBefore)} → ~${formatTokens(tokensAfter)} tokens)`)}` : '')
    );
  }

  usageLine(usage) {
    if (this.mode !== 'interactive') return;
    const parts = [
      `${formatTokens(usage.input)} in`,
      `${formatTokens(usage.output)} out`,
      ...(usage.cacheRead ? [`${formatTokens(usage.cacheRead)} cache`] : []),
      ...(usage.cost != null ? [formatCost(usage.cost)] : []),
    ];
    this.line(this.dim(`  ${parts.join(' · ')}`));
  }

  printFinal(text) {
    if (this.mode === 'print') {
      process.stdout.write(text.endsWith('\n') ? text : `${text}\n`);
    }
  }

  divider() {
    if (this.mode === 'interactive') this.line(this.dim('─'.repeat(48)));
  }
}

class MarkdownRenderer {
  constructor(ui) {
    this.ui = ui;
    this.buffer = '';
    this.inCode = false;
    this.codeLang = '';
    this.streamed = false;
    this.hadContent = false;
  }

  write(chunk) {
    this.buffer += chunk;
    let newline;
    while ((newline = this.buffer.indexOf('\n')) !== -1) {
      const line = this.buffer.slice(0, newline);
      this.buffer = this.buffer.slice(newline + 1);
      this.hadContent = true;
      if (this.streamed) {
        this.ui.raw(`${line}\n`);
        this.streamed = false;
        continue;
      }
      if (this.inCode) {
        this.renderCodeLine(line);
        continue;
      }
      this.renderLine(line);
    }
    if (!this.inCode && !this.streamed && this.buffer) {
      const safe = this.isSafeToStream(this.buffer);
      if (safe) {
        this.ui.raw(this.buffer);
        this.streamed = true;
        this.hadContent = true;
        this.buffer = '';
      }
    }
  }

  isSafeToStream(text) {
    if (!text) return false;
    if (/^\s*$/.test(text)) return false;
    if (/^\s*(```|#{1,6}\s|>|[-*+]\s|\d+[.)]\s|\||---)/.test(text)) return false;
    if (/[`*[\]]/.test(text)) return false;
    return true;
  }

  renderCodeLine(line) {
    if (/^\s*```/.test(line)) {
      this.inCode = false;
      this.ui.line(this.ui.dim('  └─') + (this.codeLang ? this.ui.dim(` ${this.codeLang}`) : ''));
      this.hadContent = true;
      return;
    }
    this.ui.raw(`${this.ui.paint('gray', line)}\n`);
    this.hadContent = true;
  }

  renderLine(line) {
    const ui = this.ui;
    this.hadContent = true;
    const fence = line.match(/^\s*```(.*)$/);
    if (fence) {
      this.inCode = true;
      this.codeLang = fence[1].trim();
      this.ui.line(ui.dim('  ┌─') + (this.codeLang ? ui.dim(` ${this.codeLang}`) : ''));
      return;
    }
    if (!line.trim()) {
      ui.raw('\n');
      return;
    }
    let match = line.match(/^(#{1,6})\s+(.*)$/);
    if (match) {
      ui.line(ui.bold(ui.cyan(this.inline(match[2]))));
      return;
    }
    if (/^\s*([-*_])\1{2,}\s*$/.test(line)) {
      ui.line(ui.dim('─'.repeat(48)));
      return;
    }
    match = line.match(/^(\s*)[-*+]\s+(.*)$/);
    if (match) {
      const checkbox = match[2].match(/^\[( |x|X)\]\s*(.*)$/);
      if (checkbox) {
        const mark = checkbox[1].toLowerCase() === 'x' ? ui.green('✔') : ui.dim('☐');
        ui.line(`${match[1]}${mark} ${this.inline(checkbox[2])}`);
      } else {
        ui.line(`${match[1]}${ui.cyan('•')} ${this.inline(match[2])}`);
      }
      return;
    }
    match = line.match(/^(\s*)(\d+[.)])\s+(.*)$/);
    if (match) {
      ui.line(`${match[1]}${ui.cyan(match[2])} ${this.inline(match[3])}`);
      return;
    }
    match = line.match(/^>\s?(.*)$/);
    if (match) {
      ui.line(`${ui.dim('│')} ${ui.italic(this.inline(match[1]))}`);
      return;
    }
    if (/^\s*\|.*\|\s*$/.test(line)) {
      ui.line(ui.dim(this.inline(line)));
      return;
    }
    ui.line(this.inline(line));
  }

  inline(text) {
    const ui = this.ui;
    if (!ui.colorEnabled) return text;
    const code = [];
    let out = String(text).replace(/`([^`]+)`/g, (_, value) => {
      code.push(value);
      return `\u0000${code.length - 1}\u0000`;
    });
    out = out.replace(/\*\*([^*]+)\*\*/g, (_, value) => ui.bold(value));
    out = out.replace(/(^|[^\w*])\*([^*\n]+)\*/g, (match, prefix, value) => `${prefix}${ui.italic(value)}`);
    out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, url) => `${ui.paint('underline', label)} ${ui.dim(`(${url})`)}`);
    out = out.replace(/\u0000(\d+)\u0000/g, (_, index) => ui.paint('yellow', code[Number(index)]));
    return out;
  }

  end() {
    if (this.buffer) {
      if (this.inCode) this.renderCodeLine(this.buffer);
      else if (this.streamed) this.ui.raw(this.buffer);
      else this.renderLine(this.buffer);
      this.buffer = '';
    }
    if (this.inCode) {
      this.ui.line(this.ui.dim('  └─'));
      this.inCode = false;
    }
    this.streamed = false;
  }
}

export function summarizeArgs(toolName, input) {
  if (!input) return '';
  if (input.description) return firstLine(input.description, 90);
  if (input.command) return firstLine(input.command, 90);
  if (input.file_path) return firstLine(String(input.file_path).split('/').slice(-2).join('/'), 90);
  if (input.pattern) return firstLine(input.pattern, 90);
  if (input.url) return firstLine(input.url, 90);
  if (input.query) return firstLine(input.query, 90);
  if (input.skill) return firstLine(input.skill, 90);
  if (input.subagent_type) return `${input.subagent_type}: ${firstLine(input.description || input.prompt || '', 70)}`;
  if (input.todos) return `${input.todos.length} todos`;
  if (input.plan) return firstLine(input.plan, 90);
  if (input.questions) return `${input.questions.length} questions`;
  if (input.path) return firstLine(input.path, 90);
  try {
    return truncateText(JSON.stringify(input), 90);
  } catch {
    return '';
  }
}
