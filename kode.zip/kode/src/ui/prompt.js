import fs from 'node:fs';
import readline from 'node:readline';
import path from 'node:path';
import { ensureDir, safeJsonParse } from '../utils.js';

export function loadHistory(file) {
  try {
    const data = safeJsonParse(fs.readFileSync(file, 'utf8'), []);
    if (Array.isArray(data)) return data.filter((entry) => typeof entry === 'string').slice(0, 500);
  } catch {}
  return [];
}

export class Prompter {
  constructor({ ui, historyFile, maxHistory = 500 }) {
    this.ui = ui;
    this.historyFile = historyFile;
    this.history = historyFile ? loadHistory(historyFile) : [];
    this.maxHistory = maxHistory;
    this.pipeReader = null;
    this.pipeQueue = [];
    this.pipeWaiters = [];
    this.pipeClosed = false;
  }

  remember(line) {
    if (!line || !line.trim()) return;
    if (this.history[0] === line) return;
    this.history = [line, ...this.history.filter((entry) => entry !== line)].slice(0, this.maxHistory);
    if (!this.historyFile) return;
    try {
      ensureDir(path.dirname(this.historyFile), 0o700);
      fs.writeFileSync(this.historyFile, JSON.stringify(this.history), { mode: 0o600 });
    } catch {}
  }

  ensurePipeReader() {
    if (this.pipeReader) return;
    this.pipeReader = readline.createInterface({ input: process.stdin, terminal: false });
    this.pipeReader.on('line', (line) => {
      if (this.pipeWaiters.length) this.pipeWaiters.shift()(line);
      else this.pipeQueue.push(line);
    });
    this.pipeReader.on('close', () => {
      this.pipeClosed = true;
      while (this.pipeWaiters.length) this.pipeWaiters.shift()(null);
    });
  }

  async askLine(promptText = '') {
    if (!process.stdin.isTTY) {
      this.ensurePipeReader();
      if (this.pipeQueue.length) return this.pipeQueue.shift();
      if (this.pipeClosed) return null;
      return new Promise((resolve) => this.pipeWaiters.push(resolve));
    }
    return new Promise((resolve) => {
      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
        terminal: true,
        historySize: this.maxHistory,
        history: this.history.slice(0, this.maxHistory),
        removeHistoryDuplicates: true,
      });
      let settled = false;
      const finish = (value, remember = true) => {
        if (settled) return;
        settled = true;
        this.ui.promptActive = false;
        if (remember && value && String(value).trim()) this.remember(value);
        try {
          rl.close();
        } catch {}
        resolve(value);
      };
      this.ui.promptActive = true;
      rl.on('SIGINT', () => finish(undefined, false));
      rl.on('line', (line) => finish(line));
      rl.on('close', () => finish(null, false));
      rl.setPrompt(promptText);
      rl.prompt();
    });
  }

  async readInput(promptText) {
    let text = await this.askLine(promptText);
    if (text === null || text === undefined) return text;
    while (text.endsWith('\\')) {
      const next = await this.askLine(this.ui.dim('... '));
      if (next === null || next === undefined) break;
      text = `${text.slice(0, -1)}\n${next}`;
    }
    return text;
  }

  async askSecret(promptText = '') {
    if (!process.stdin.isTTY) return this.askLine(promptText);
    process.stdout.write(promptText);
    return new Promise((resolve) => {
      const stdin = process.stdin;
      let value = '';
      let settled = false;
      this.ui.promptActive = true;
      stdin.setRawMode(true);
      stdin.resume();
      stdin.setEncoding('utf8');
      const cleanup = () => {
        if (settled) return;
        settled = true;
        this.ui.promptActive = false;
        stdin.removeListener('data', onData);
        stdin.setRawMode(false);
        stdin.pause();
        process.stdout.write('\n');
      };
      const onData = (data) => {
        for (const char of data) {
          if (char === '\r' || char === '\n') {
            cleanup();
            resolve(value);
            return;
          }
          if (char === '\u0003') {
            cleanup();
            process.exit(130);
          }
          if (char === '\u007f' || char === '\b') {
            if (value.length) {
              value = value.slice(0, -1);
              process.stdout.write('\b \b');
            }
            continue;
          }
          if (char >= ' ') {
            value += char;
            process.stdout.write('*');
          }
        }
      };
      stdin.on('data', onData);
    });
  }

  async choose(promptText, options, { defaultIndex = 0, allowCustom = false } = {}) {
    const ui = this.ui;
    ui.line('');
    options.forEach((option, index) => {
      const label = typeof option === 'string' ? option : option.label;
      const description = typeof option === 'string' ? '' : option.description;
      const marker = index === defaultIndex ? ui.cyan('›') : ' ';
      ui.line(`  ${marker} ${ui.bold(String(index + 1))}. ${label}${description ? ` ${ui.dim(`— ${description}`)}` : ''}`);
    });
    if (allowCustom) ui.line(`  ${ui.dim('Enter a number, a custom value, or leave blank for the default.')}`);
    const answer = await this.askLine(`${promptText} `);
    if (answer === null) return null;
    if (answer === undefined) return options[defaultIndex];
    const trimmed = answer.trim();
    if (!trimmed) return options[defaultIndex];
    const number = Number(trimmed);
    if (Number.isInteger(number) && number >= 1 && number <= options.length) return options[number - 1];
    if (allowCustom) return trimmed;
    ui.warn('Invalid selection.');
    return options[defaultIndex];
  }

  async askPermission({ toolName, summary }) {
    const ui = this.ui;
    if (ui.mode !== 'interactive') return { decision: 'deny', reason: 'non-interactive mode' };
    ui.line('');
    ui.line(`${ui.yellow('Permission required')} ${ui.bold(toolName)}${summary ? ` ${ui.dim(summary)}` : ''}`);
    const answer = await this.askLine(
      `${ui.dim('[y]es  [a]lways this session  [A]lways and save  [n]o')} ${ui.cyan('›')} `
    );
    if (answer === undefined) return { decision: 'deny', reason: 'interrupted' };
    if (answer === null) return { decision: 'deny', reason: 'no input' };
    const choice = answer.trim();
    if (choice === 'a') return { decision: 'always' };
    if (choice === 'A') return { decision: 'always-save' };
    if (choice === 'y' || choice === 'yes' || choice === 'Y') return { decision: 'allow' };
    return { decision: 'deny', reason: 'user denied' };
  }

  async askQuestions(questions) {
    const ui = this.ui;
    if (ui.mode !== 'interactive') {
      throw new Error('AskUserQuestion is unavailable in non-interactive mode. Pick sensible defaults and continue.');
    }
    const answers = [];
    for (const question of questions) {
      ui.line('');
      ui.line(`${ui.bold(question.header || 'Question')}: ${question.question}`);
      (question.options || []).forEach((option, index) => {
        ui.line(`  ${ui.bold(String(index + 1))}. ${option.label}${option.description ? ` ${ui.dim(`— ${option.description}`)}` : ''}`);
      });
      if (question.multiSelect) ui.line(ui.dim('Select one or more numbers separated by commas.'));
      const hint = question.multiSelect ? ui.dim('numbers, text, or blank to skip') : ui.dim('number, text, or blank to skip');
      const answer = await this.askLine(`${hint} ${ui.cyan('›')} `);
      if (answer === undefined || answer === null) break;
      const trimmed = answer.trim();
      if (!trimmed) {
        answers.push({ header: question.header, question: question.question, answers: ['(no answer)'] });
        continue;
      }
      const chosen = [];
      for (const part of trimmed.split(/[,\s]+/).filter(Boolean)) {
        const index = Number(part);
        if (Number.isInteger(index) && question.options?.[index - 1]) chosen.push(question.options[index - 1].label);
      }
      answers.push({
        header: question.header,
        question: question.question,
        answers: chosen.length ? chosen : [trimmed],
      });
    }
    return answers;
  }

  async confirmPlan(plan) {
    const ui = this.ui;
    ui.line('');
    ui.line(ui.magenta('Plan'));
    ui.line(plan);
    ui.line('');
    const answer = await this.askLine(`${ui.dim('[y]es, implement  [n]o, keep planning  [f]eedback')} ${ui.cyan('›')} `);
    if (answer === undefined || answer === null) return { approved: false };
    const trimmed = answer.trim();
    if (trimmed === 'y' || trimmed === 'yes') return { approved: true };
    if (trimmed.toLowerCase() === 'f') {
      const feedback = await this.askLine('Feedback: ');
      return { approved: false, feedback: feedback || '' };
    }
    return { approved: false };
  }

  close() {
    try {
      this.pipeReader?.close();
    } catch {}
  }
}
