import fs from 'node:fs';
import path from 'node:path';
import { KODE_HOME, USER_MEMORY_DIR, projectPaths } from './config.js';
import { truncateText } from './utils.js';

const INSTRUCTION_NAMES = ['KODE.md', 'AGENTS.md', 'CLAUDE.md', path.join('.kode', 'KODE.md')];

export function readCapped(file, cap = 32768) {
  try {
    return truncateText(fs.readFileSync(file, 'utf8'), cap);
  } catch {
    return '';
  }
}

export function discoverInstructionFiles(cwd) {
  const found = [];
  const seen = new Set();
  let dir = path.resolve(cwd);
  for (;;) {
    for (const name of INSTRUCTION_NAMES) {
      const file = path.join(dir, name);
      if (seen.has(file)) continue;
      try {
        const stat = fs.statSync(file);
        if (stat.isFile()) {
          seen.add(file);
          found.push(file);
        }
      } catch {}
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  const globalFile = path.join(KODE_HOME, 'KODE.md');
  if (fs.existsSync(globalFile) && !seen.has(globalFile)) found.push(globalFile);
  return found;
}

export function buildMemoryContext(cwd) {
  const instructionFiles = discoverInstructionFiles(cwd);
  const sections = [];
  let total = 0;
  for (const file of instructionFiles) {
    const content = readCapped(file, 32768);
    if (!content.trim()) continue;
    const section = `### ${file}\n\n${content}`;
    if (total + section.length > 160000) break;
    sections.push(section);
    total += section.length;
  }

  const projectMemory = projectPaths(cwd).memory;
  const memoryIndices = [];
  for (const dir of [projectMemory, USER_MEMORY_DIR]) {
    const indexPath = path.join(dir, 'MEMORY.md');
    if (!fs.existsSync(indexPath)) continue;
    const content = readCapped(indexPath, 20000);
    if (content.trim()) memoryIndices.push(`### ${indexPath}\n\n${content}`);
  }

  return {
    instructionFiles,
    sections,
    memoryIndices,
    projectMemory,
    userMemory: USER_MEMORY_DIR,
  };
}

export function listMemoryFiles(dir, { max = 200 } = {}) {
  const out = [];
  const walk = (current, depth) => {
    if (out.length >= max || depth > 4) return;
    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue;
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) walk(full, depth + 1);
      else if (entry.isFile() && entry.name.endsWith('.md')) {
        try {
          out.push({ path: full, size: fs.statSync(full).size });
        } catch {}
      }
    }
  };
  walk(dir, 0);
  return out;
}
