import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'kode-smoke-'));
const home = path.join(temp, 'home');
const workspace = path.join(temp, 'workspace');
fs.mkdirSync(home, { recursive: true });
fs.mkdirSync(workspace, { recursive: true });
fs.writeFileSync(path.join(workspace, 'a.js'), 'export const answer = 42;\n');
fs.writeFileSync(path.join(workspace, 'b.txt'), 'not javascript\n');

process.env.KODE_HOME = home;
process.env.NO_COLOR = '1';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`✓ ${name}`);
  } catch (err) {
    console.error(`✗ ${name}\n${err.stack || err.message}`);
    process.exitCode = 1;
    throw err;
  }
}

const utils = await import('../src/utils.js');
const configModule = await import('../src/config.js');
const permissions = await import('../src/permissions.js');
const anthropic = await import('../src/providers/anthropic.js');
const openai = await import('../src/providers/openai.js');
const google = await import('../src/providers/google.js');
const commandsModule = await import('../src/custom-commands.js');
const { parseArgs } = await import('../src/cli.js');

test('glob matching handles **, *, ?, braces', () => {
  assert.equal(utils.matchGlob('src/agent/agent.js', 'src/**/*.js'), true);
  assert.equal(utils.matchGlob('src/index.js', 'src/**/*.js'), true);
  assert.equal(utils.matchGlob('test/smoke.js', 'src/**/*.js'), false);
  assert.equal(utils.matchGlob('file.ts', '*.{js,ts}'), true);
  assert.equal(utils.matchGlob('file.md', '*.{js,ts}'), false);
  assert.equal(utils.matchGlob('a1.js', 'a?.js'), true);
});

test('frontmatter parses scalars, arrays and body', () => {
  const parsed = utils.parseFrontmatter('---\nname: demo\ntags: [a, b]\ncount: 3\nok: true\n---\nbody here');
  assert.equal(parsed.data.name, 'demo');
  assert.deepEqual(parsed.data.tags, ['a', 'b']);
  assert.equal(parsed.data.count, 3);
  assert.equal(parsed.data.ok, true);
  assert.equal(parsed.body, 'body here');
});

test('diffLines reports additions and removals', () => {
  const ops = utils.diffLines('a\nb', 'a\nc');
  assert.ok(ops.some((op) => op.type === 'del' && op.line === 'b'));
  assert.ok(ops.some((op) => op.type === 'add' && op.line === 'c'));
  const stats = utils.diffStats(ops);
  assert.equal(stats.add, 1);
  assert.equal(stats.del, 1);
});

test('htmlToText strips tags and decodes entities', () => {
  const text = utils.htmlToText('<h1>Hello &amp; welcome</h1><script>x()</script><p>Body</p>');
  assert.match(text, /Hello & welcome/);
  assert.match(text, /Body/);
  assert.doesNotMatch(text, /<h1>|x\(\)/);
});

test('permission rules: deny wins, edits and plan mode behave', () => {
  const config = {
    permissions: { mode: 'default', allow: [], deny: [] },
  };
  const session = { mode: 'default', allowRules: [], denyRules: [] };
  assert.equal(
    permissions.evaluatePermission({ toolName: 'Bash', input: { command: 'rm -rf x' }, config, session, cwd: workspace }).decision,
    'ask'
  );
  assert.equal(
    permissions.evaluatePermission({
      toolName: 'Bash',
      input: { command: 'npm test' },
      config: { permissions: { allow: ['Bash(npm test:*)'], deny: [] } },
      session,
      cwd: workspace,
    }).decision,
    'allow'
  );
  assert.equal(
    permissions.evaluatePermission({
      toolName: 'Bash',
      input: { command: 'rm -rf x' },
      config: { permissions: { allow: [], deny: ['Bash(rm:*)'] } },
      session,
      cwd: workspace,
    }).decision,
    'deny'
  );
  session.mode = 'acceptEdits';
  assert.equal(
    permissions.evaluatePermission({ toolName: 'Edit', input: { file_path: 'a.js' }, config, session, cwd: workspace }).decision,
    'allow'
  );
  session.mode = 'plan';
  assert.equal(
    permissions.evaluatePermission({ toolName: 'Write', input: { file_path: 'a.js' }, config, session, cwd: workspace }).decision,
    'deny'
  );
  assert.equal(
    permissions.evaluatePermission({ toolName: 'Task', input: { prompt: 'x' }, config, session, cwd: workspace }).decision,
    'allow'
  );
  assert.equal(
    permissions.evaluatePermission({ toolName: 'Glob', input: { pattern: '*' }, config, session, cwd: workspace }).decision,
    'allow'
  );
});

test('provider conversions preserve tool calls and results', () => {
  const messages = [
    { role: 'user', content: [{ type: 'text', text: 'hi' }] },
    {
      role: 'assistant',
      content: [
        { type: 'text', text: 'reading' },
        { type: 'tool_use', id: 't1', name: 'Read', input: { file_path: '/x' } },
      ],
    },
    {
      role: 'user',
      content: [{ type: 'tool_result', tool_use_id: 't1', content: 'file data' }],
    },
  ];
  const oa = openai.toOpenAIMessages('system', messages);
  assert.equal(oa[0].role, 'system');
  assert.equal(oa[2].tool_calls[0].function.name, 'Read');
  assert.equal(oa[3].role, 'tool');
  assert.equal(oa[3].tool_call_id, 't1');

  const an = anthropic.toAnthropicMessages(messages);
  assert.equal(an[1].content[1].type, 'tool_use');
  assert.equal(an[2].content[0].type, 'tool_result');

  const g = google.toGoogleContents(messages);
  assert.equal(g[1].parts.find((part) => part.functionCall).functionCall.name, 'Read');
  assert.equal(g[2].parts[0].functionResponse.name, 'Read');
});

test('custom command expansion supports arguments', () => {
  const command = { body: 'Review $1 with $ARGUMENTS' };
  assert.equal(commandsModule.expandCommand(command, 'src/app.js thoroughly'), 'Review src/app.js with src/app.js thoroughly');
});

test('CLI parser handles flags and prompts', () => {
  const parsed = parseArgs([
    '-p',
    '--model',
    'openai/gpt-5',
    '--permission-mode',
    'plan',
    '--allowed-tools',
    'Read,Bash(npm test:*)',
    'fix',
    'the',
    'bug',
  ]);
  assert.equal(parsed.options.print, true);
  assert.equal(parsed.options.model, 'openai/gpt-5');
  assert.equal(parsed.options.permissionMode, 'plan');
  assert.deepEqual(parsed.options.allowedTools, ['Read', 'Bash(npm test:*)']);
  assert.equal(parsed.prompt, 'fix the bug');
  const resume = parseArgs(['-r', 'ses_123', 'continue']);
  assert.equal(resume.options.resume, 'ses_123');
  assert.equal(resume.prompt, 'continue');
});

test('pricing estimate for known model', () => {
  const config = configModule.loadConfig();
  const cost = configModule.estimateCost(config, 'anthropic', 'claude-sonnet-4-5', {
    input: 1_000_000,
    output: 1_000_000,
  });
  assert.equal(Math.round(cost * 100) / 100, 18);
});

function sse(res, events) {
  res.writeHead(200, {
    'content-type': 'text/event-stream',
    'cache-control': 'no-cache',
    connection: 'keep-alive',
  });
  for (const event of events) res.write(`data: ${JSON.stringify(event)}\n\n`);
  res.write('data: [DONE]\n\n');
  res.end();
}

async function runEndToEnd() {
  const requests = [];
  const server = http.createServer(async (req, res) => {
    let body = '';
    for await (const chunk of req) body += chunk;
    let parsed;
    try {
      parsed = JSON.parse(body);
    } catch {
      parsed = {};
    }
    requests.push(parsed);
    if (requests.length === 1) {
      sse(res, [
        {
          id: 'chatcmpl-1',
          object: 'chat.completion.chunk',
          choices: [
            {
              index: 0,
              delta: {
                role: 'assistant',
                tool_calls: [
                  {
                    index: 0,
                    id: 'call_1',
                    type: 'function',
                    function: { name: 'Glob', arguments: JSON.stringify({ pattern: '*.js' }) },
                  },
                ],
              },
              finish_reason: null,
            },
          ],
        },
        { id: 'chatcmpl-1', choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }] },
        {
          id: 'chatcmpl-1',
          choices: [],
          usage: { prompt_tokens: 100, completion_tokens: 20, total_tokens: 120 },
        },
      ]);
    } else {
      sse(res, [
        {
          id: 'chatcmpl-2',
          choices: [{ index: 0, delta: { content: 'DONE' }, finish_reason: null }],
        },
        { id: 'chatcmpl-2', choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] },
        { id: 'chatcmpl-2', choices: [], usage: { prompt_tokens: 150, completion_tokens: 5 } },
      ]);
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const config = {
    version: 1,
    provider: 'openai',
    model: 'mock-model',
    maxTokens: 1024,
    maxTurns: 10,
    permissions: { mode: 'bypassPermissions', allow: [], deny: [] },
    ui: { spinner: false, verbose: false },
    providers: {
      openai: { apiKey: 'test-key', baseURL: `http://127.0.0.1:${port}/v1` },
    },
    mcpServers: {},
    hooks: {},
  };
  fs.writeFileSync(path.join(home, 'config.json'), JSON.stringify(config, null, 2), { mode: 0o600 });

  const run = await new Promise((resolve) => {
    const child = spawn(process.execPath, [path.join(root, 'bin', 'kode.js'), '-p', '--output-format', 'json', 'list the js files'], {
      cwd: workspace,
      env: {
        ...process.env,
        KODE_HOME: home,
        KODE_NO_SPINNER: '1',
        NO_COLOR: '1',
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk;
    });
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
    }, 30000);
    child.on('error', (err) => {
      clearTimeout(timer);
      resolve({ status: 1, stdout, stderr: `${stderr}${err.message}`, signal: null });
    });
    child.on('close', (status, signal) => {
      clearTimeout(timer);
      resolve({ status, stdout, stderr, signal });
    });
  });
  server.close();

  assert.equal(run.status, 0, `exit ${run.status}\nstdout:\n${run.stdout}\nstderr:\n${run.stderr}`);
  const lines = run.stdout.trim().split('\n').filter(Boolean);
  const result = JSON.parse(lines[lines.length - 1]);
  assert.equal(result.type, 'result');
  assert.equal(result.subtype, 'success');
  assert.equal(result.result, 'DONE');
  assert.equal(result.turns, 2);
  assert.equal(result.usage.input, 250);
  assert.equal(result.usage.output, 25);
  assert.ok(!/\u001b\[/.test(run.stdout), 'JSON output should not contain ANSI escapes');

  assert.equal(requests.length, 2, 'expected two model requests');
  assert.equal(requests[0].stream, true);
  assert.ok(Array.isArray(requests[0].tools) && requests[0].tools.some((tool) => tool.function?.name === 'Glob'));
  assert.ok(
    requests[1].messages.some(
      (message) => message.role === 'tool' && message.tool_call_id === 'call_1' && /a\.js/.test(message.content)
    ),
    `second request should include the Glob result: ${JSON.stringify(requests[1].messages)}`
  );

  const projectRoot = path.join(home, 'projects');
  const sessionFiles = fs
    .readdirSync(projectRoot)
    .flatMap((dir) => {
      const sessions = path.join(projectRoot, dir, 'sessions');
      return fs.existsSync(sessions) ? fs.readdirSync(sessions).map((name) => path.join(sessions, name)) : [];
    });
  assert.equal(sessionFiles.length, 1, 'one session file should be saved');
  const saved = JSON.parse(fs.readFileSync(sessionFiles[0], 'utf8'));
  assert.equal(saved.messages.length, 4);
  assert.equal(saved.messages[0].role, 'user');
  assert.equal(saved.messages[1].content.some((block) => block.type === 'tool_use'), true);
  assert.equal(saved.messages[2].content[0].type, 'tool_result');
  assert.equal(saved.messages[3].content[0].text, 'DONE');
  assert.equal(saved.usage.requests, 2);
  assert.equal(saved.usage.input, 250);
}

try {
  await runEndToEnd();
  console.log('✓ end-to-end mock provider (stream + tool loop + JSON output + session persistence)');
  passed++;
} catch (err) {
  console.error(`✗ end-to-end mock provider\n${err.stack || err.message}`);
  process.exitCode = 1;
}

function writeMockConfig(port) {
  fs.writeFileSync(
    path.join(home, 'config.json'),
    JSON.stringify(
      {
        version: 1,
        provider: 'openai',
        model: 'mock-model',
        maxTokens: 1024,
        maxTurns: 10,
        permissions: { mode: 'bypassPermissions', allow: [], deny: [] },
        ui: { spinner: false, verbose: false },
        providers: { openai: { apiKey: 'test-key', baseURL: `http://127.0.0.1:${port}/v1` } },
        mcpServers: {},
        hooks: {},
      },
      null,
      2
    ),
    { mode: 0o600 }
  );
}

async function runKode(args, { stdin = null } = {}) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [path.join(root, 'bin', 'kode.js'), ...args], {
      cwd: workspace,
      env: { ...process.env, KODE_HOME: home, KODE_NO_SPINNER: '1', NO_COLOR: '1' },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk;
    });
    if (stdin != null) child.stdin.end(stdin);
    else child.stdin.end();
    const timer = setTimeout(() => child.kill('SIGKILL'), 30000);
    child.on('close', (status, signal) => {
      clearTimeout(timer);
      resolve({ status, signal, stdout, stderr });
    });
  });
}

function sessionFiles() {
  const projectRoot = path.join(home, 'projects');
  if (!fs.existsSync(projectRoot)) return [];
  return fs.readdirSync(projectRoot).flatMap((dir) => {
    const sessions = path.join(projectRoot, dir, 'sessions');
    return fs.existsSync(sessions) ? fs.readdirSync(sessions).map((name) => path.join(sessions, name)) : [];
  });
}

function textResponse(res, content, id = 'mock') {
  sse(res, [
    { id, choices: [{ index: 0, delta: { content }, finish_reason: null }] },
    { id, choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] },
    { id, choices: [], usage: { prompt_tokens: 10, completion_tokens: 3 } },
  ]);
}

function toolResponse(res, name, args, id = 'mock') {
  sse(res, [
    {
      id,
      choices: [
        {
          index: 0,
          delta: {
            role: 'assistant',
            tool_calls: [
              { index: 0, id: `call_${name}`, type: 'function', function: { name, arguments: JSON.stringify(args) } },
            ],
          },
          finish_reason: null,
        },
      ],
    },
    { id, choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }] },
    { id, choices: [], usage: { prompt_tokens: 10, completion_tokens: 5 } },
  ]);
}

async function runSubagentTest() {
  const requests = [];
  const server = http.createServer(async (req, res) => {
    let body = '';
    for await (const chunk of req) body += chunk;
    const parsed = JSON.parse(body);
    requests.push(parsed);
    const system = parsed.messages?.[0]?.content || '';
    if (typeof system === 'string' && /running as a .*subagent/.test(system)) {
      textResponse(res, 'SUB DONE');
    } else if (parsed.messages.some((message) => message.role === 'tool')) {
      textResponse(res, 'PARENT DONE');
    } else {
      toolResponse(res, 'Task', { description: 'research', prompt: 'Find the answer', subagent_type: 'general' });
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  writeMockConfig(server.address().port);
  const before = sessionFiles().length;
  const run = await runKode(['-p', '--output-format', 'json', 'delegate this']);
  server.close();

  assert.equal(run.status, 0, `subagent run failed\n${run.stdout}\n${run.stderr}`);
  const lines = run.stdout.trim().split('\n').filter(Boolean);
  const result = JSON.parse(lines[lines.length - 1]);
  assert.equal(result.result, 'PARENT DONE');
  assert.equal(requests.length, 3, 'expected parent, subagent, and parent-final requests');
  const subRequest = requests[1];
  assert.match(String(subRequest.messages[0].content), /subagent/);
  assert.ok(
    !subRequest.tools.some((tool) => ['Task', 'AskUserQuestion', 'ExitPlanMode'].includes(tool.function?.name)),
    'subagents must not receive Task, AskUserQuestion, or ExitPlanMode'
  );
  assert.equal(sessionFiles().length, before + 1, 'subagent sessions should not be saved as project sessions');
  const saved = JSON.parse(fs.readFileSync(sessionFiles().sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0], 'utf8'));
  assert.ok(saved.messages[1].content.some((block) => block.type === 'tool_use' && block.name === 'Task'));
  assert.equal(saved.messages.at(-1).content[0].text, 'PARENT DONE');
}

async function runReplTest() {
  const requests = [];
  const server = http.createServer(async (req, res) => {
    let body = '';
    for await (const chunk of req) body += chunk;
    requests.push(JSON.parse(body));
    textResponse(res, 'PONG');
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  writeMockConfig(server.address().port);
  const run = await runKode([], { stdin: 'hello\n/status\n/exit\n' });
  server.close();

  assert.equal(run.status, 0, `repl run failed\nstdout:\n${run.stdout}\nstderr:\n${run.stderr}`);
  assert.match(run.stdout, /PONG/);
  assert.match(run.stdout, /Status/);
  assert.match(run.stdout, /provider: openai/);
  assert.match(run.stdout, /session:/);
  assert.equal(requests.length, 1, 'REPL should send exactly one model request');
}

for (const [name, fn] of [
  ['subagent Task tool and isolated context', runSubagentTest],
  ['piped REPL with slash commands', runReplTest],
]) {
  try {
    await fn();
    console.log(`✓ ${name}`);
    passed++;
  } catch (err) {
    console.error(`✗ ${name}\n${err.stack || err.message}`);
    process.exitCode = 1;
  }
}

for (const dir of [home, workspace]) {
  try {
    fs.rmSync(dir, { recursive: true, force: true });
  } catch {}
}

if (process.exitCode) {
  console.error('\nsmoke test failed');
} else {
  console.log(`\nsmoke test passed: ${passed} checks`);
}
