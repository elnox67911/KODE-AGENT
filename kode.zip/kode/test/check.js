import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const failures = [];
let count = 0;

function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full));
    else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

const files = [...walk(path.join(root, 'src')), path.join(root, 'bin', 'kode.js')];
for (const file of files) {
  count++;
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) {
    failures.push(`${path.relative(root, file)}\n${result.stderr.trim()}`);
  }
}

const modules = [
  'src/config.js',
  'src/utils.js',
  'src/permissions.js',
  'src/session.js',
  'src/mcp.js',
  'src/hooks.js',
  'src/skills.js',
  'src/memory.js',
  'src/custom-commands.js',
  'src/agent/agent.js',
  'src/agent/context.js',
  'src/agent/prompt.js',
  'src/commands.js',
  'src/setup.js',
  'src/doctor.js',
  'src/cli.js',
  'src/index.js',
  'src/providers/anthropic.js',
  'src/providers/openai.js',
  'src/providers/google.js',
  'src/providers/http.js',
  'src/providers/index.js',
  'src/tools/fs.js',
  'src/tools/bash.js',
  'src/tools/web.js',
  'src/tools/todo.js',
  'src/tools/memory.js',
  'src/tools/skill.js',
  'src/tools/task.js',
  'src/tools/ask.js',
  'src/tools/plan.js',
];
for (const module of modules) {
  count++;
  try {
    await import(new URL(module, `file://${root}/`).href);
  } catch (err) {
    failures.push(`${module}: ${err.stack || err.message}`);
  }
}

const toolsModule = await import(new URL('src/tools/index.js', `file://${root}/`).href);
const tools = toolsModule.BUILTIN_TOOLS;
const expected = [
  'Read',
  'Write',
  'Edit',
  'Glob',
  'Grep',
  'Bash',
  'BashOutput',
  'KillShell',
  'WebFetch',
  'WebSearch',
  'TodoWrite',
  'Memory',
  'Skill',
  'Task',
  'AskUserQuestion',
  'ExitPlanMode',
];
for (const name of expected) {
  count++;
  if (!tools.some((tool) => tool.name === name)) failures.push(`Missing built-in tool: ${name}`);
}
for (const tool of tools) {
  count++;
  if (!tool.name || !tool.description || !tool.inputSchema || typeof tool.run !== 'function') {
    failures.push(`Tool is missing required fields: ${tool.name || '(unnamed)'}`);
  }
  if (tool.inputSchema?.type !== 'object') failures.push(`Tool schema must be an object: ${tool.name}`);
}

count++;
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (!fs.existsSync(path.join(root, pkg.bin.kode))) failures.push('package.json bin path does not exist');
if (pkg.type !== 'module') failures.push('package.json must have "type": "module"');

if (failures.length) {
  console.error(`check failed (${failures.length} of ${count} checks)\n`);
  for (const failure of failures) console.error(`✗ ${failure}`);
  process.exit(1);
}
console.log(`check passed: ${count} checks across ${files.length} files`);
